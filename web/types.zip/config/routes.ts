﻿export const  adminRoutes :any =  {
 
  // routes  : [
  
  //   {
      path: '/admin',
      name: 'admin',
      icon: 'crown',
      access: 'canAdmin',
      routes: [
        {
          path: '/admin',
          redirect: '/admin/students/list',
        },
        {
          path: '/admin/students/list',
          name: 'users-list',
          component: './admin/students/StudentsList',
        },
        {
          path: '/admin/student/add',
          name: 'sub-page',
          component: './admin/students/AddStudentForm',
        },
        {
          path: '/admin/grammer/check',
          name: 'grammer-check',
          component: './admin/education',
        },
        {
          path: '/admin/chat',
          name: 'chat',
          component: './admin/chat',
        },
        {
          path: '/admin/student/view',
          name: 'view-student',
          hideInMenu: true,
          component: './admin/students/ViewStudent',
        },

      ],
  //   },
  //   {
  //     name: 'list.table-list',
  //     icon: 'table',
  //     path: '/list',
  //     component: './TableList',
  //   },
  //   {
  //     path: '*',
  //     layout: false,
  //     component: './404',
  //   },
  // ]

}
