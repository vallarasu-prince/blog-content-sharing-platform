import { PageContainer, ProTable } from '@ant-design/pro-components';
import React, { useEffect, useState } from 'react';
import { getUsersList } from './Services';
import { useModel } from '@umijs/max';


const UsersList = (props:any) => {
    const [data, setData] = useState<any>([]);
    const { initialState } = useModel('@@initialState');
    const { currentUser } = initialState || {};
  
    useEffect(() => {
        getUsers();

    }, []);

    const getUsers = async () => {
        const { status, class:className, payload } = await getUsersList();

        if (status == 1) {
            setData(payload)
        }

    }

    return (
        <PageContainer>
            <ProTable 
                columns={[
                    {
                        title: 'Name',
                        dataIndex: 'name',
                        valueType: 'text',
                    },
                ]}
                dataSource={data}
                pagination={{ pageSize: 10 }}
                toolBarRender={false}
                search={false}
            />
        </PageContainer>

    )
}

export default UsersList;