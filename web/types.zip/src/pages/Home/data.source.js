import React from 'react';

export const Nav00DataSource = {
  wrapper: { className: 'header0 home-page-wrapper' },
  page: { className: 'home-page' },
  logo: {
    className: 'header0-logo',
    children: "https://res.cloudinary.com/dz878qel5/image/upload/v1674388655/sm/logo_vdycww.png",
    title : 'V Schools',
  },
  Menu: {
    className: 'header0-menu',
    children: [
      {
        name: 'item0',
        className: 'header0-item',
        children: {
          href: '#',
          children: [{ children: 'Home', name: 'text' }],
        },
        // subItem: [
        //   {
        //     name: 'sub0',
        //     className: 'item-sub',
        //     children: {
        //       className: 'item-sub-item',
        //       children: [
        //         {
        //           name: 'image0',
        //           className: 'item-image',
        //           children:
        //             'https://gw.alipayobjects.com/zos/rmsportal/ruHbkzzMKShUpDYMEmHM.svg',
        //         },
        //         {
        //           name: 'title',
        //           className: 'item-title',
        //           children: 'Ant Design',
        //         },
        //         {
        //           name: 'content',
        //           className: 'item-content',
        //           children: '企业级 UI 设计体系',
        //         },
        //       ],
        //     },
        //   },
        //   {
        //     name: 'sub1',
        //     className: 'item-sub',
        //     children: {
        //       className: 'item-sub-item',
        //       children: [
        //         {
        //           name: 'image0',
        //           className: 'item-image',
        //           children:
        //             'https://gw.alipayobjects.com/zos/rmsportal/ruHbkzzMKShUpDYMEmHM.svg',
        //         },
        //         {
        //           name: 'title',
        //           className: 'item-title',
        //           children: 'Ant Design',
        //         },
        //         {
        //           name: 'content',
        //           className: 'item-content',
        //           children: '企业级 UI 设计体系',
        //         },
        //       ],
        //     },
        //   },
        // ],
      },
      {
        name: 'item1',
        className: 'header0-item',
        children: {
          href: '#',
          children: [{ children: 'Contact', name: 'text' }],
        },
      },
      {
        name: 'item2',
        className: 'header0-item',
        children: {
          href: '#',
          children: [{ children: 'About us', name: 'text' }],
        },
      },
      {
        name: 'item3',
        className: 'header0-item',
        children: {
          href: '#',
          children: [{ children: 'Login', name: 'text' }],
        },
      },
    ],
  },
  mobileMenu: { className: 'header0-mobile-menu' },
};
export const Banner01DataSource = {
  wrapper: { className: 'banner0' },
  textWrapper: { className: 'banner0-text-wrapper' },
  title: {
    className: 'banner0-title',
    children: "https://res.cloudinary.com/dz878qel5/image/upload/v1674388655/sm/logo_vdycww.png",
  },
  content: {
    className: 'banner0-content',
    children: "Welcome to V Schools ! We are thrilled to have you as part of our community. Our mission is to provide a high-quality education that prepares students for success in a rapidly changing world. We believe that every student is unique and has the potential to make a positive impact on the world. That's why we offer a wide range of academic and extracurricular programs designed to meet the needs of each individual student.",
  },
  button: { className: 'banner0-button', children: 'Learn More' },
};
export const Content110DataSource = {
  OverPack: {
    className: 'home-page-wrapper content11-wrapper',
    playScale: 0.3,
  },
  titleWrapper: {
    className: 'title-wrapper',
    children: [
      // {
      //   name: 'image',
      //   children:
      //     'https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg',
      //   className: 'title-image',
      // },
      { name: 'title', children: 'Our Goal', className: 'title-h1' },
      {
        name: 'content',
        children:
          '',
        className: 'title-content',
      },
      {
        name: 'content2',
        children: 'We strive to create a nurturing and inclusive environment where students can grow, learn, and thrive. Our dedicated faculty and staff are committed to helping students reach their full potential. We also place a strong emphasis on building strong relationships with our families and the larger community.',
        className: 'title-content',
      },
    ],
  },
  button: {
    className: '',
    children: { a: { className: 'button', href: '#', children: 'Explore' } },
  },
};

export const Feature10DataSource = {
  wrapper: { className: 'home-page-wrapper content1-wrapper' },
  OverPack: { className: 'home-page content1', playScale: 0.3 },
  imgWrapper: { className: 'content1-img', md: 10, xs: 24 },
  img: {
    children: 'https://zos.alipayobjects.com/rmsportal/nLzbeGQLPyBJoli.png',
  },
  textWrapper: { className: 'content1-text', md: 14, xs: 24 },
  title: { className: 'content1-title', children: 'Correspondent, ' },
  content: {
    className: 'content1-content',
    children: ' " We are committed to providing a high-quality education that prepares students for success in a rapidly changing world. We believe that every student is unique and has the potential to make a positive impact on the world. That’s why we offer a wide range of academic and extracurricular programs designed to meet the needs of each individual student. "',
  },
};
export const Content00DataSource = {
  wrapper: { className: 'home-page-wrapper content0-wrapper' },
  page: { className: 'home-page content0' },
  OverPack: { playScale: 0.3, className: '' },
  titleWrapper: {
    className: 'title-wrapper',
    children: [{ name: 'title', children: '' }],
  },
  childWrapper: {
    className: 'content0-block-wrapper',
    children: [
      {
        name: 'block0',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://zos.alipayobjects.com/rmsportal/WBnVOjtIlGWbzyQivuyq.png',
            },
            {
              name: 'title',
              className: 'content0-block-title',
              children: '5',
            },
            { name: 'content', children: 'Awards' },
          ],
        },
      },
      {
        name: 'block1',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://zos.alipayobjects.com/rmsportal/YPMsLQuCEXtuEkmXTTdk.png',
            },
            {
              name: 'title',
              className: 'content0-block-title',
              children: '130'
            },
            {
              name: 'content',
              children: 'Certified Teachers',
            },
          ],
        },
      },
      {
        name: 'block2',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://zos.alipayobjects.com/rmsportal/EkXWVvAaFJKCzhMmQYiX.png',
            },
            {
              name: 'title',
              className: 'content0-block-title',
              children: '1000+',
            },
            {
              name: 'content',
              children: 'Happy Students',
            },
          ],
        },
      },
    ],
  },
};
export const Feature70DataSource = {
  wrapper: { className: 'home-page-wrapper feature7-wrapper' },
  page: { className: 'home-page feature7' },
  OverPack: { playScale: 0.3 },
  titleWrapper: {
    className: 'feature7-title-wrapper',
    children: [
      {
        name: 'title',
        className: 'feature7-title-h1',
        children: 'What We Do',
      },
      {
        name: 'content',
        className: 'feature7-title-content',
        children: ''
      },
    ],
  },
  blockWrapper: {
    className: 'feature7-block-wrapper',
    gutter: 24,
    children: [
      {
        md: 6,
        xs: 24,
        name: 'block0',
        className: 'feature7-block',
        children: {
          className: 'feature7-block-group',
          children: [
            {
              name: 'image',
              className: 'feature7-block-image',
              children:
                'https://gw.alipayobjects.com/zos/basement_prod/e339fc34-b022-4cde-9607-675ca9e05231.svg',
            },
            {
              name: 'title',
              className: 'feature7-block-title',
              children: 'Computer Education',
            },
            {
              name: 'content',
              className: 'feature7-block-content',
              children: 'We provide computer education to students from 1st to 12th standard. We also provide computer education to students who are preparing for competitive exams like JEE, NEET, etc.',
            },
          ],
        },
      },
      {
        md: 6,
        xs: 24,
        name: 'block1',
        className: 'feature7-block',
        children: {
          className: 'feature7-block-group',
          children: [
            {
              name: 'image',
              className: 'feature7-block-image',
              children:
                'https://gw.alipayobjects.com/zos/basement_prod/e339fc34-b022-4cde-9607-675ca9e05231.svg',
            },
            {
              name: 'title',
              className: 'feature7-block-title',
              children: 'Online Classes',
            },
            {
              name: 'content',
              className: 'feature7-block-content',
              children: 'We provide online classes for students who are unable to attend regular classes due to any reason.',
            },
          ],
        },
      },
      {
        md: 6,
        xs: 24,
        name: 'block2',
        className: 'feature7-block',
        children: {
          className: 'feature7-block-group',
          children: [
            {
              name: 'image',
              className: 'feature7-block-image',
              children:
                'https://gw.alipayobjects.com/zos/basement_prod/e339fc34-b022-4cde-9607-675ca9e05231.svg',
            },
            {
              name: 'title',
              className: 'feature7-block-title',
              children: 'English Lab'
            },
            {
              name: 'content',
              className: 'feature7-block-content',
              children: 'We provide English lab for students who are preparing for competitive exams like JEE, NEET, etc.',
            },
          ],
        },
      },
      {
        md: 6,
        xs: 24,
        name: 'block3',
        className: 'feature7-block',
        children: {
          className: 'feature7-block-group',
          children: [
            {
              name: 'image',
              className: 'feature7-block-image',
              children:
                'https://gw.alipayobjects.com/zos/basement_prod/e339fc34-b022-4cde-9607-675ca9e05231.svg',
            },
            {
              name: 'title',
              className: 'feature7-block-title',
              children: 'School App',
            },
            {
              name: 'content',
              className: 'feature7-block-content',
              children: 'We provide school app for students and parents. Students can access their study material, assignments, etc. Parents can access their child\'s attendance, marks, etc.',
            },
          ],
        },
      }
    ],
  },
};
export const Content90DataSource = {
  wrapper: { className: 'home-page-wrapper content9-wrapper' },
  page: { className: 'home-page content9' },
  titleWrapper: {
    className: 'title-wrapper',
    children: [
      {
        name: 'image',
        children:
          'https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg',
        className: 'title-image',
      },
      { name: 'title', children: '会议日程', className: 'title-h1' },
    ],
  },
  block: {
    className: 'timeline',
    children: [
      {
        name: 'block0',
        className: 'block-wrapper',
        playScale: 0.3,
        children: {
          imgWrapper: { className: 'image-wrapper' },
          textWrapper: { className: 'text-wrapper' },
          img: {
            className: 'block-img',
            children:
              'https://gw.alipayobjects.com/zos/rmsportal/SlFgHDtOTLzccvFrQHLg.png',
          },
          icon: {
            className: 'block-icon',
            children:
              'https://gw.alipayobjects.com/zos/rmsportal/qJnGrvjXPxdKETlVSrbe.svg',
          },
          name: { className: 'block-name', children: '姓名' },
          post: { className: 'block-post', children: '公司 职位' },
          time: { className: 'block-time', children: '09:00 - 10:00' },
          title: { className: 'block-title', children: '开幕致辞' },
          content: { className: 'block-content', children: '' },
        },
      },
      {
        name: 'block1',
        className: 'block-wrapper',
        playScale: 0.3,
        children: {
          imgWrapper: { className: 'image-wrapper' },
          textWrapper: { className: 'text-wrapper' },
          img: {
            className: 'block-img',
            children:
              'https://gw.alipayobjects.com/zos/rmsportal/SlFgHDtOTLzccvFrQHLg.png',
          },
          icon: {
            className: 'block-icon',
            children:
              'https://gw.alipayobjects.com/zos/rmsportal/QviGtUPvTFxdhsTUAacr.svg',
          },
          name: { className: 'block-name', children: '姓名' },
          post: { className: 'block-post', children: '公司 职位' },
          time: { className: 'block-time', children: '09:00 - 10:00' },
          title: { className: 'block-title', children: '演示标题 - XYZ' },
          content: {
            className: 'block-content',
            children:
              '经过近 3 年的打磨，在助力中台产品研发效能提升的目标之上，包含设计语言、UI 资产、可视化以及产品体验相关的蚂蚁中台设计体系正在逐步成型。此次分享包含两部分，在介绍蚂蚁设计体系的同时，也会和大家分享我们在设计语言的部分探索。',
          },
        },
      },
      {
        name: 'block2',
        className: 'block-wrapper',
        playScale: 0.3,
        children: {
          imgWrapper: { className: 'image-wrapper' },
          textWrapper: { className: 'text-wrapper' },
          img: {
            className: 'block-img',
            children:
              'https://gw.alipayobjects.com/zos/rmsportal/SlFgHDtOTLzccvFrQHLg.png',
          },
          icon: {
            className: 'block-icon',
            children:
              'https://gw.alipayobjects.com/zos/rmsportal/QviGtUPvTFxdhsTUAacr.svg',
          },
          name: { className: 'block-name', children: '姓名' },
          post: { className: 'block-post', children: '公司 职位' },
          time: { className: 'block-time', children: '09:00 - 10:00' },
          title: { className: 'block-title', children: '演示标题 - XYZ' },
          content: {
            className: 'block-content',
            children:
              '经过近 3 年的打磨，在助力中台产品研发效能提升的目标之上，包含设计语言、UI 资产、可视化以及产品体验相关的蚂蚁中台设计体系正在逐步成型。此次分享包含两部分，在介绍蚂蚁设计体系的同时，也会和大家分享我们在设计语言的部分探索。',
          },
        },
      },
      {
        name: 'block3',
        className: 'block-wrapper',
        playScale: 0.3,
        children: {
          imgWrapper: { className: 'image-wrapper' },
          textWrapper: { className: 'text-wrapper' },
          img: {
            className: 'block-img',
            children:
              'https://gw.alipayobjects.com/zos/rmsportal/SlFgHDtOTLzccvFrQHLg.png',
          },
          icon: {
            className: 'block-icon',
            children:
              'https://gw.alipayobjects.com/zos/rmsportal/agOOBdKEIJlQhfeYhHJc.svg',
          },
          name: { className: 'block-name', children: '姓名' },
          post: { className: 'block-post', children: '公司 职位' },
          time: { className: 'block-time', children: '09:00 - 10:00' },
          title: { className: 'block-title', children: '演示标题 - XYZ' },
          content: {
            className: 'block-content',
            children:
              '经过近 3 年的打磨，在助力中台产品研发效能提升的目标之上，包含设计语言、UI 资产、可视化以及产品体验相关的蚂蚁中台设计体系正在逐步成型。此次分享包含两部分，在介绍蚂蚁设计体系的同时，也会和大家分享我们在设计语言的部分探索。',
          },
        },
      },
    ],
  },
};
export const Content30DataSource = {
  wrapper: { className: 'home-page-wrapper content3-wrapper' },
  page: { className: 'home-page content3' },
  OverPack: { playScale: 0.3 },
  titleWrapper: {
    className: 'title-wrapper',
    children: [
      {
        name: 'title',
        children: '蚂蚁金融云提供专业的服务',
        className: 'title-h1',
      },
      {
        name: 'content',
        className: 'title-content',
        children: '基于阿里云强大的基础资源',
      },
    ],
  },
  block: {
    className: 'content3-block-wrapper',
    children: [
      {
        name: 'block0',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/ScHBSdwpTkAHZkJ.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '企业资源管理' },
          content: {
            className: 'content3-content',
            children:
              '云资源集中编排、弹性伸缩、持续发布和部署，高可用及容灾。',
          },
        },
      },
      {
        name: 'block1',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/NKBELAOuuKbofDD.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '云安全' },
          content: {
            className: 'content3-content',
            children:
              '按金融企业安全要求打造的完整云上安全体系，全方位保障金融应用及数据安全。',
          },
        },
      },
      {
        name: 'block2',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/xMSBjgxBhKfyMWX.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '云监控' },
          content: {
            className: 'content3-content',
            children:
              '分布式云环境集中监控，统一资源及应用状态视图，智能分析及故障定位。',
          },
        },
      },
      {
        name: 'block3',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/MNdlBNhmDBLuzqp.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '移动' },
          content: {
            className: 'content3-content',
            children:
              '一站式移动金融APP开发及全面监控；丰富可用组件，动态发布和故障热修复。',
          },
        },
      },
      {
        name: 'block4',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/UsUmoBRyLvkIQeO.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '分布式中间件' },
          content: {
            className: 'content3-content',
            children:
              '金融级联机交易处理中间件，大规模分布式计算机，数万笔/秒级并发能力，严格保证交易数据统一性。',
          },
        },
      },
      {
        name: 'block5',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/ipwaQLBLflRfUrg.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '大数据' },
          content: {
            className: 'content3-content',
            children:
              '一站式、全周期大数据协同工作平台，PB级数据处理、毫秒级数据分析工具。',
          },
        },
      },
    ],
  },
};
export const Teams30DataSource = {
  wrapper: { className: 'home-page-wrapper teams3-wrapper' },
  page: { className: 'home-page teams3' },
  OverPack: { playScale: 0.3, className: '' },
  titleWrapper: {
    className: 'title-wrapper',
    children: [{ name: 'title', children: 'Our Achievers', className: 'title-h1' }],
  },
  blockTop: {
    className: 'block-top-wrapper',
    children: [
      {
        name: 'block0',
        className: 'block-top',
        md: 8,
        xs: 24,
        titleWrapper: {
          children: [
            {
              name: 'image',
              className: 'teams3-top-image',
              children:
                'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*--rVR4hclJYAAAAAAAAAAABjARQnAQ',
            },
            {
              name: 'title',
              className: 'teams3-top-title',
              children: 'Rajesh',
            },
            {
              name: 'content',
              className: 'teams3-top-job',
              children: '1 st Rank',
            },
            {
              name: 'content1',
              className: 'teams3-top-content',
              children:
                '12th Science, 1st Rank, 2018',
            },
          ],
        },
      },
      {
        name: 'block1',
        className: 'block-top',
        md: 8,
        xs: 24,
        titleWrapper: {
          children: [
            {
              name: 'image',
              className: 'teams3-top-image',
              children:
                'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*njqxS5Ky7CQAAAAAAAAAAABjARQnAQ',
            },
            { name: 'title', className: 'teams3-top-title', children: 'Kumar' },
            {
              name: 'content',
              className: 'teams3-top-job',
              children: '2 nd Rank',
            },
            {
              name: 'content1',
              className: 'teams3-top-content',
              children:
                '12th Science, 2nd Rank, 2018',
            },
          ],
        },
      },
      {
        name: 'block2',
        className: 'block-top',
        md: 8,
        xs: 24,
        titleWrapper: {
          children: [
            {
              name: 'image',
              className: 'teams3-top-image',
              children:
                'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*--rVR4hclJYAAAAAAAAAAABjARQnAQ',
            },
            {
              name: 'title',
              className: 'teams3-top-title',
              children: 'Vivek',
            },
            {
              name: 'content',
              className: 'teams3-top-job',
              children: '3 rd Rank',
            },
            {
              name: 'content1',
              className: 'teams3-top-content',
              children:
                '12th Science, 3rd Rank, 2018',
            },
          ],
        },
      },
    ],
  },
  block: {
    className: 'block-wrapper',
    gutter: 72,
    children: [
      // {
      //   name: 'block0',
      //   className: 'block',
      //   md: 8,
      //   xs: 24,
      //   image: {
      //     name: 'image',
      //     className: 'teams3-image',
      //     children:
      //       'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*--rVR4hclJYAAAAAAAAAAABjARQnAQ',
      //   },
      //   titleWrapper: {
      //     className: 'teams3-textWrapper',
      //     children: [
      //       { name: 'title', className: 'teams3-title', children: '叶秀英' },
      //       {
      //         name: 'content',
      //         className: 'teams3-job',
      //         children: '公司+职位 信息暂缺',
      //       },
      //       {
      //         name: 'content1',
      //         className: 'teams3-content',
      //         children: 'AntV 是蚂蚁金服全新一代数据可视化解决方案。',
      //       },
      //     ],
      //   },
      // },
      // {
      //   name: 'block1',
      //   className: 'block',
      //   md: 8,
      //   xs: 24,
      //   image: {
      //     name: 'image',
      //     className: 'teams3-image',
      //     children:
      //       'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*njqxS5Ky7CQAAAAAAAAAAABjARQnAQ',
      //   },
      //   titleWrapper: {
      //     className: 'teams3-textWrapper',
      //     children: [
      //       { name: 'title', className: 'teams3-title', children: '韩勇' },
      //       {
      //         name: 'content',
      //         className: 'teams3-job',
      //         children: '公司+职位 信息暂缺',
      //       },
      //       {
      //         name: 'content1',
      //         className: 'teams3-content',
      //         children: '语雀是一款优雅高效的在线文档编辑与协同工具。',
      //       },
      //     ],
      //   },
      // },
      // {
      //   name: 'block2',
      //   className: 'block',
      //   md: 8,
      //   xs: 24,
      //   image: {
      //     name: 'image',
      //     className: 'teams3-image',
      //     children:
      //       'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*--rVR4hclJYAAAAAAAAAAABjARQnAQ',
      //   },
      //   titleWrapper: {
      //     className: 'teams3-textWrapper',
      //     children: [
      //       { name: 'title', className: 'teams3-title', children: '叶秀英' },
      //       {
      //         name: 'content',
      //         className: 'teams3-job',
      //         children: '公司+职位 信息暂缺',
      //       },
      //       {
      //         name: 'content1',
      //         className: 'teams3-content',
      //         children: 'AntV 是蚂蚁金服全新一代数据可视化解决方案。',
      //       },
      //     ],
      //   },
      // },
      // {
      //   name: 'block3',
      //   className: 'block',
      //   md: 8,
      //   xs: 24,
      //   image: {
      //     name: 'image',
      //     className: 'teams3-image',
      //     children:
      //       'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*--rVR4hclJYAAAAAAAAAAABjARQnAQ',
      //   },
      //   titleWrapper: {
      //     className: 'teams3-textWrapper',
      //     children: [
      //       { name: 'title', className: 'teams3-title', children: '叶秀英' },
      //       {
      //         name: 'content',
      //         className: 'teams3-job',
      //         children: '公司+职位 信息暂缺',
      //       },
      //       {
      //         name: 'content1',
      //         className: 'teams3-content',
      //         children: 'AntV 是蚂蚁金服全新一代数据可视化解决方案。',
      //       },
      //     ],
      //   },
      // },
      // {
      //   name: 'block4',
      //   className: 'block',
      //   md: 8,
      //   xs: 24,
      //   image: {
      //     name: 'image',
      //     className: 'teams3-image',
      //     children:
      //       'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*njqxS5Ky7CQAAAAAAAAAAABjARQnAQ',
      //   },
      //   titleWrapper: {
      //     className: 'teams3-textWrapper',
      //     children: [
      //       { name: 'title', className: 'teams3-title', children: '韩勇' },
      //       {
      //         name: 'content',
      //         className: 'teams3-job',
      //         children: '公司+职位 信息暂缺',
      //       },
      //       {
      //         name: 'content1',
      //         className: 'teams3-content',
      //         children: '语雀是一款优雅高效的在线文档编辑与协同工具。',
      //       },
      //     ],
      //   },
      // },
      // {
      //   name: 'block5',
      //   className: 'block',
      //   md: 8,
      //   xs: 24,
      //   image: {
      //     name: 'image',
      //     className: 'teams3-image',
      //     children:
      //       'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*--rVR4hclJYAAAAAAAAAAABjARQnAQ',
      //   },
      //   titleWrapper: {
      //     className: 'teams3-textWrapper',
      //     children: [
      //       { name: 'title', className: 'teams3-title', children: '叶秀英' },
      //       {
      //         name: 'content',
      //         className: 'teams3-job',
      //         children: '公司+职位 信息暂缺',
      //       },
      //       {
      //         name: 'content1',
      //         className: 'teams3-content',
      //         children: 'AntV 是蚂蚁金服全新一代数据可视化解决方案。',
      //       },
      //     ],
      //   },
      // },
      // {
      //   name: 'block6',
      //   className: 'block',
      //   md: 8,
      //   xs: 24,
      //   image: {
      //     name: 'image',
      //     className: 'teams3-image',
      //     children:
      //       'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*--rVR4hclJYAAAAAAAAAAABjARQnAQ',
      //   },
      //   titleWrapper: {
      //     className: 'teams3-textWrapper',
      //     children: [
      //       { name: 'title', className: 'teams3-title', children: '叶秀英' },
      //       {
      //         name: 'content',
      //         className: 'teams3-job',
      //         children: '公司+职位 信息暂缺',
      //       },
      //       {
      //         name: 'content1',
      //         className: 'teams3-content',
      //         children: 'AntV 是蚂蚁金服全新一代数据可视化解决方案。',
      //       },
      //     ],
      //   },
      // },
      // {
      //   name: 'block7',
      //   className: 'block',
      //   md: 8,
      //   xs: 24,
      //   image: {
      //     name: 'image',
      //     className: 'teams3-image',
      //     children:
      //       'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*njqxS5Ky7CQAAAAAAAAAAABjARQnAQ',
      //   },
      //   titleWrapper: {
      //     className: 'teams3-textWrapper',
      //     children: [
      //       { name: 'title', className: 'teams3-title', children: '韩勇' },
      //       {
      //         name: 'content',
      //         className: 'teams3-job',
      //         children: '公司+职位 信息暂缺',
      //       },
      //       {
      //         name: 'content1',
      //         className: 'teams3-content',
      //         children: '语雀是一款优雅高效的在线文档编辑与协同工具。',
      //       },
      //     ],
      //   },
      // },
      // {
      //   name: 'block8',
      //   className: 'block',
      //   md: 8,
      //   xs: 24,
      //   image: {
      //     name: 'image',
      //     className: 'teams3-image',
      //     children:
      //       'https://gw.alipayobjects.com/mdn/rms_ae7ad9/afts/img/A*--rVR4hclJYAAAAAAAAAAABjARQnAQ',
      //   },
      //   titleWrapper: {
      //     className: 'teams3-textWrapper',
      //     children: [
      //       { name: 'title', className: 'teams3-title', children: '叶秀英' },
      //       {
      //         name: 'content',
      //         className: 'teams3-job',
      //         children: '公司+职位 信息暂缺',
      //       },
      //       {
      //         name: 'content1',
      //         className: 'teams3-content',
      //         children: 'AntV 是蚂蚁金服全新一代数据可视化解决方案。',
      //       },
      //     ],
      //   },
      // },
    ],
  },
};
export const Footer10DataSource = {
  wrapper: { className: 'home-page-wrapper footer1-wrapper' },
  OverPack: { className: 'footer1', playScale: 0.2 },
  block: {
    className: 'home-page',
    gutter: 0,
    children: [
      {
        name: 'block0',
        xs: 24,
        md: 6,
        className: 'block',
        title: {
          className: 'logo',
          children:
            'https://res.cloudinary.com/dz878qel5/image/upload/v1674388655/sm/logo_vdycww.png',
        },
        childWrapper: {
          className: 'slogan',
          children: [
            {
              name: 'content0',
              children: '',
            },
          ],
        },
      },
      {
        name: 'block1',
        xs: 24,
        md: 6,
        className: 'block',
        title: { children: '' },
        childWrapper: {
          children: [
            { name: 'link0', href: '#', children: 'About us'},
            { name: 'link1', href: '#', children: 'Gallery' },
            // { name: 'link2', href: '#', children: 'FAQ' },
            // { name: 'link3', href: '#', children: 'Contact us' },
          ],
        },
      },
      {
        name: 'block2',
        xs: 24,
        md: 6,
        className: 'block',
        title: { children: 'Quick Links' },
        childWrapper: {
          children: [
            { href: '#', name: 'link0', children: 'FAQ' },
            { href: '#', name: 'link1', children: 'Contact us' },
          ],
        },
      },
      {
        name: 'block3',
        xs: 24,
        md: 6,
        className: 'block',
        title: { children: 'Follow us' },
        childWrapper: {
          children: [
            { href: '#', name: 'link0', children: 'Instagram' },
            { href: '#', name: 'link1', children: 'Facebook' },
          ],
        },
      },
    ],
  },
  copyrightWrapper: { className: 'copyright-wrapper' },
  copyrightPage: { className: 'home-page' },
  copyright: {
    className: 'copyright',
    children: (
      <span>
        ©2023 V Schools All Rights
        Reserved
      </span>
    ),
  },
};
