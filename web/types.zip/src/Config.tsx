
export const G_PRODUCT_NAME = 'V Schools';
export const G_PRODUCT_DESCRIPTION = 'V Schools is a platform for learning and teaching.';
export const G_LOGO_URL = 'https://res.cloudinary.com/dz878qel5/image/upload/v1674388655/sm/logo_vdycww.png';


export const G_PRODUCTION = false;

