import React from 'react';

const HomeLayout: React.FC = (props) => {
    return <>{props.children}</>;
    };