
export const G_CLASS_OPTIONS = [
    { key: '1', label: 'Class 1' },
    { key: '2', label: 'Class 2' },
    { key: '3', label: 'Class 3' },
    { key: '4', label: 'Class 4' },
    { key: '5', label: 'Class 5' },
    { key: '6', label: 'Class 6' },
    { key: '7', label: 'Class 7' },
    { key: '8', label: 'Class 8' },
    { key: '9', label: 'Class 9' },
    { key: '10', label: 'Class 10' },
    { key: '11', label: 'Class 11' },
    { key: '12', label: 'Class 12' },
];

export const G_SECTION_OPTIONS = [
    { key: 'a', label: 'Section A' },
    { key: 'b', label: 'Section B' },
    { key: 'c', label: 'Section C' },
    { key: 'd', label: 'Section D' },
    { key: 'e', label: 'Section E' },
    { key: 'f', label: 'Section F' },
    { key: 'g', label: 'Section G' },
];
